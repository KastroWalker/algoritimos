#!/usr/bin/python
# -*- coding: utf-8 -*-

x = float(input('Digite um número: '))
y = float(input('Digite outro número: '))

x, y = y, x

print(f'x: {x}\ny: {y}')