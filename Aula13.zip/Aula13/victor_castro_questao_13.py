#!/usr/bin/python
# -*- coding: utf-8 -*-

age = int(input('Digite sua idade: '))

if age > 18 and age < 67:
    print('Você pode doar sangue')
else:
    print('Você não pode doar sangue')
