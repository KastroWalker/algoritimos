#!/usr/bin/python
# -*- coding: utf-8 -*-

number = int(input('Digite um número: '))

if number % 2 == 0:
    print(f'{number} é par')
else:
    print(f'{number} é impar')